const shell = require("shelljs");

const execCommand = (command, log) => {
  const commands = {
    log: () => {
      shell.exec(`tar -cf ./.logs/${log}.tar .`);
      console.log("Sucess");
    }
  };

  return commands[command];
};

const main = () => {
  const args = process.argv.slice(2);
  const command = args[0];
  const log = args[1];
  execCommand(command, log)();
};

main();
